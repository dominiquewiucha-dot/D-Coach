﻿# DCoach Exercise Library DataOnly Handoff

Umgesetzt als reine Datenpflege.

Kandidaten geprueft: 31
Bereits vorhanden / unter anderer ID vorhanden: 10
Als Alias ergaenzt: 24 Datensaetze ueber geladene Datenquellen
Neu angelegt: 21
Uebersprungen: 0
Duplikate gefunden: 0 Alias-Kollisionen in Seed/Core

Keine App-Logik geaendert.
Keine Aenderung an app.js, index.html, styles.css oder production/production-muscle-map.js.
sw.js wurde nur beim CACHE_NAME von dcoach-pwa-v85 auf dcoach-pwa-v86 geaendert, damit neue JSON-Daten ausgeliefert werden.

Hinweis:
ex_pec_deck_machine wurde nicht neu angelegt, weil ex_pec_deck bereits die normale Butterfly Maschine ist. Aliase wurden dort ergaenzt.
