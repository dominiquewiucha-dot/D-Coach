﻿# Open Risks

- tibialis_anterior has no dedicated canonical muscle ID in data/muscles.json. It is mapped to mg_calves as the closest existing lower-leg bucket. No new muscle ID was created.
- sw.js changed only CACHE_NAME. app.js APP_CACHE_VERSION remains dcoach-pwa-v85 because app.js is explicitly forbidden by this package.
- Plan generator was not changed and will only benefit from data availability where existing generator/search logic already reads exercise records.
