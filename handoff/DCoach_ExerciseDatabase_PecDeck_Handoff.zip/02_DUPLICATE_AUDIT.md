﻿# Duplicate Audit

Gefundene relevante IDs/Aliase vor Aenderung:
- ex_pec_deck existierte bereits als normale Pec-Deck-/Butterfly-Uebung.
- ex_reverse_pec_deck existierte als Reverse Butterfly und bleibt getrennt.
- Varianten ex_pec_deck_neutral, ex_pec_deck_wide, ex_pec_deck_close existieren separat.

Entscheidung:
- Kein ex_pec_deck_machine hinzugefuegt, weil dies dieselbe normale Uebung doppelt angelegt haette.
- ex_pec_deck ist die kanonische bestehende ID fuer die normale Butterfly Maschine.

Validierung:
- Keine doppelte Exercise-ID in seed_training_database.json.
- Keine doppelte Exercise-ID in data/exercise_core_v2.1.0.json.
- Normale Butterfly und Reverse Butterfly haben verschiedene IDs.
