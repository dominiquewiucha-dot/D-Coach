﻿# Open Risks

- Teil 2 Plan-Generator-Upgrade ist nicht umgesetzt. Das Paket verlangt dafuer Hoch und eine separate Freigabe.
- Bestehende Plan-Generator-Logik bleibt simpel; Teil 1 stellt nur sicher, dass Butterfly Maschine korrekt als Push/Brust-Exercise klassifiziert ist.
- PWA-Clients muessen pwa-v85 laden, damit die geaenderten JSON-Daten aktiv werden.
