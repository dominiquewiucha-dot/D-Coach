﻿# DCoach Exercise Database Pec Deck Handoff

Teil 1 aus DCoach_ExerciseDatabase_PlanGenerator_Upgrade wurde umgesetzt.

Entscheidung:
- Keine neue ID ex_pec_deck_machine angelegt.
- Bestehende normale Pec-Deck-Uebung ex_pec_deck wurde vervollstaendigt.
- Grund: ex_pec_deck war bereits die normale Butterfly-/Pec-Deck-Maschine; eine zweite ID waere ein Duplikat.

Umgesetzt:
- Anzeige auf Butterfly Maschine gesetzt.
- Aliase ergaenzt.
- Push/Brust/Maschine/LWS/Hypertrophie-Tags ergaenzt.
- Defaults auf 2 Saetze, 10-15 Wdh., 75 s Pause gesetzt.
- Trizeps aus normalem Butterfly-Mapping entfernt.
- Front Delt bleibt als kleiner Hilfsmuskel erhalten.
- Reverse Butterfly unveraendert als Pull/Rear-Delt abgegrenzt.
- PWA Cache auf pwa-v85 erhoeht.

Teil 2 Plan-Generator wurde bewusst nicht gestartet.
