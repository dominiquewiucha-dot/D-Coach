﻿# DCoach Bugfix02 Direct Replacement No Duplicates Handoff v5

Branch: fix/direct-exercise-replacement-no-duplicates

Umgesetzt:
- Alternativen im laufenden Workout werden vor Anzeige gegen belegte exerciseId-Werte im aktuellen Draft gefiltert.
- Die aktuell ersetzte Position ist von der Belegungspruefung ausgeschlossen.
- Die gleiche Uebung wie aktuell wird nicht vorgeschlagen.
- Doppelte Uebernahme wird direkt vor dem Speichern erneut blockiert.
- Draft bleibt bei blockiertem Duplikat unveraendert.
- plannedExerciseId, exerciseId und alternativeForExerciseId werden getrennt gespeichert.
- PWA Cache-Buster auf pwa-v84 aktualisiert.

Nicht geaendert:
- Keine Navigation.
- Kein Coach.
- Keine Muscle Map.
- Kein Plan-Generator.
- Keine Storage-Key-Aenderung.
